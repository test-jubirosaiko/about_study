#pragma once

enum Window {
	WIDTH = 800,
	HEIGHT = 1000
};

enum {BLOCK_MAX = 13};